package sudoku;

import java.util.ArrayList;

public class matrix {

	int[] liste;
	int[] liste1;
	int[][] b;
	int d;
	int k;
	boolean hilfewurdeausgef�hrt;
	int AnzahlBackTracking;
	ArrayList<Integer> L�sungsArray;

	public matrix(int d) {

		k = (int) Math.pow(d, 2);
		b = new int[k][k];
		liste = new int[k];
		liste1 = new int[k];
		this.d = d;
		for (int i = 0; i < k; i++) {
			liste[i] = i + 1;
			liste1[i] = i + 1;
		}
		hilfewurdeausgef�hrt = false;
		AnzahlBackTracking = 0;
	}

	// true wenn das sudoku gel�st ist
	public boolean issolved() {

		for (int m = 0; m < k; m = m + d) {
			for (int n = 0; n < k; n = n + d) {

				for (int i = m; i < m + d; i++) {
					for (int j = n; j < n + d; j++) {
						if (contains(liste, b[i][j])) {

							if (contains(liste1, b[i][j])) {
								�berschreiben(liste1, b[i][j]);
							} else {

								liste1 = liste.clone();
								return false;
							}
						}
					}
				}

				if (!consistsof(liste1)) {
					liste1 = liste.clone();
					return false;
				} else {
					liste1 = liste.clone();
				}
			}
		}

		for (int i = 0; i < k; i++) {
			for (int j = 0; j < k; j++) {

				if (contains(liste, b[i][j])) {

					if (contains(liste1, b[i][j])) {
						�berschreiben(liste1, b[i][j]);
					} else {

						liste1 = liste.clone();
						return false;
					}
				} else {
					return false;
				}
			}
			if (!consistsof(liste1)) {
				liste1 = liste.clone();
				return false;
			} else {
				liste1 = liste.clone();
			}
		}

		for (int j = 0; j < k; j++) {
			for (int i = 0; i < k; i++) {

				if (contains(liste, b[i][j])) {

					if (contains(liste1, b[i][j])) {
						�berschreiben(liste1, b[i][j]);
					} else {

						liste1 = liste.clone();
						return false;
					}
				} else {
					return false;
				}
			}
			if (!consistsof(liste1)) {
				liste1 = liste.clone();
				return false;
			} else {
				liste1 = liste.clone();
			}
		}

		return true;
	}

	// true wenn regeln des aktuellen sudokus nicht verletzt sind.
	public boolean RegelnNichtVerletzt() {

		for (int m = 0; m < k; m = m + d) {
			for (int n = 0; n < k; n = n + d) {
				for (int i = m; i < m + d; i++) {
					for (int j = n; j < n + d; j++) {

						if (!(b[i][j] == 0)) {
							if (contains(liste, b[i][j])) {

								if (contains(liste1, b[i][j])) {
									�berschreiben(liste1, b[i][j]);
								} else {

									liste1 = liste.clone();
									return false;
								}
							} else {
								liste1 = liste.clone();
								return false;
							}
						} else {
							continue;
						}
					}
				}

				liste1 = liste.clone();

			}
		}

		for (int i = 0; i < k; i++) {
			liste1 = liste.clone();
			for (int j = 0; j < k; j++) {

				if (b[i][j] == 0) {
					continue;
				}
				if (contains(liste1, b[i][j])) {
					�berschreiben(liste1, b[i][j]);
				} else {

					liste1 = liste.clone();
					return false;
				}

			}
		}

		for (int j = 0; j < k; j++) {
			liste1 = liste.clone();
			for (int i = 0; i < k; i++) {

				if (b[i][j] == 0) {
					continue;
				}
				if (contains(liste1, b[i][j])) {
					�berschreiben(liste1, b[i][j]);
				} else {

					liste1 = liste.clone();
					return false;
				}

			}
		}

		return true;
	}

//l�st das sudoku falls machbar oder wirft einen Fehler.
	public void solving() throws sudokuException {

		if (!this.RegelnNichtVerletzt()) {
			sudokuException e = new sudokuException();
			throw e;
		}

		for (int i = 0; i < k; i++) {

			for (int j = 0; j < k; j++) {

				if (b[i][j] == 0) {

					for (int l = 1; l < k + 1; l++) {

						if (this.issolved()) {
							return;
						}

						b = hilfe(l, b, i, j, b[i][j]).clone();

						if (hilfewurdeausgef�hrt == false && l == k) {
							AnzahlBackTracking++;
							b[i][j] = 0;
							return;
						}

						if (hilfewurdeausgef�hrt == true) {
							this.solving();
						} else
							continue;

					}
				}

				else
					continue;
			}
		}
	}

//	 gibt die matrix zur�ck mit b[i][j]= l, wenn es die regeln nicht verletzt, ansonsten nur b.	
	public int[][] hilfe(int l, int[][] o, int i, int j, int u) {

		matrix p = new matrix(d);
		int[][] result = new int[k][k];
		result = o.clone();

		result[i][j] = l;
		p.b = result.clone();

		if (p.RegelnNichtVerletzt()) {

			hilfewurdeausgef�hrt = true;
			return result;
		} else {
			hilfewurdeausgef�hrt = false;
			o[i][j] = u;
			return o;
		}

	}

	// l�scht die Zellen der Matrix

	public void clear() {
		matrix matrix = new matrix(this.d);
		copy(matrix);
	}

	public void copy2(matrix matrix) {
		for (int i = 0; i < k; i++) {
			for (int j = 0; j < k; j++) {
				b[i][j] = matrix.b[i][j];
			}
		}
	}

	public void copy(matrix matrix) {
		this.liste = matrix.liste;
		this.AnzahlBackTracking = matrix.AnzahlBackTracking;
		this.liste1 = matrix.liste1;
		this.b = matrix.b;
		this.hilfewurdeausgef�hrt = matrix.hilfewurdeausgef�hrt;
	}

	// gibt in einer ArrayList alle m�glichen L�sungen f�r die Zelle (i,j) an.
	public ArrayList<Integer> AlleL�sungen(int i, int j) {

		ArrayList<Integer> L�sung = new ArrayList<>();
		for (int o = 1; o < k + 1; o++) {
			matrix matrix = new matrix(d);
			matrix.copy2(this);

			matrix.b[i][j] = o;

			try {
				matrix.solving();
			} catch (Exception e) {
				continue;
			}
			L�sung.add(o);
		}
		return L�sung;

	}

	private boolean contains(int[] a, int b) {
		for (int i = 0; i < a.length; i++) {
			if (a[i] == b) {
				return true;
			}
		}
		return false;
	}

	private void �berschreiben(int[] a, int b) {
		for (int i = 0; i < a.length; i++) {
			if (a[i] == b) {
				a[i] = -1;
			}
		}
	}

	private boolean consistsof(int[] a) {
		for (int i = 0; i < a.length; i++) {
			if (!(a[i] == -1)) {
				return false;
			}
		}
		return true;
	}

	public void add(int a) {
		for (int i = 0; i < k; i++) {
			for (int j = 0; j < k; j++) {
				if (b[i][j] == 0) {
					b[i][j] = a;
					return;
				}
			}
		}

	}

}
