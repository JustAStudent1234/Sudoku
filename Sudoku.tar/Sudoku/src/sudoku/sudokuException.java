package sudoku;

public class sudokuException extends Exception {

	public sudokuException() {
		super("Das eingegebene Sudoku ist nicht l�sbar");
	}

}
