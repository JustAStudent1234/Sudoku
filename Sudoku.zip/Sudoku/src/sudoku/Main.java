package sudoku;

import java.util.ArrayList;

import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {

		GUISUDOKU h = new GUISUDOKU();

	}
}
